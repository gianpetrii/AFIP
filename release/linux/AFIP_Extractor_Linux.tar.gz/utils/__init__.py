"""
Paquete de utilidades para el Extractor AFIP.

Este paquete contiene módulos con funciones y clases 
que proporcionan utilidades para el funcionamiento
del Extractor AFIP.
"""

__version__ = '1.0.0' 